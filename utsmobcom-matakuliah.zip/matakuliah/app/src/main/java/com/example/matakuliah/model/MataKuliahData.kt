package com.example.matakuliah.model

import com.example.matakuliah.R

object MataKuliahRepository {
    val mataKuliah = listOf(
        MataKuliah(
            matkulRes = R.string.matakuliah1,
            sksRes = R.string.sks1,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah2,
            sksRes = R.string.sks2,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah3,
            sksRes = R.string.sks3,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah4,
            sksRes = R.string.sks4,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah5,
            sksRes = R.string.sks5,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah6,
            sksRes = R.string.sks6,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah7,
            sksRes = R.string.sks7,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah8,
            sksRes = R.string.sks8,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah9,
            sksRes = R.string.sks9,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah10,
            sksRes = R.string.sks10,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah11,
            sksRes = R.string.sks11,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah12,
            sksRes = R.string.sks12,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah13,
            sksRes = R.string.sks13,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah14,
            sksRes = R.string.sks14,
            imageRes = R.drawable.lambang_unj
        ),
        MataKuliah(
            matkulRes = R.string.matakuliah15,
            sksRes = R.string.sks15,
            imageRes = R.drawable.lambang_unj
        ),


    )
}